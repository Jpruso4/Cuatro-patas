module.exports.secrets = {
    jwtSecret: "48nfHg7X9C0gKkHJnxzHRNk_h7uie-KaVVzBJdZazIFub7UqlFklHL_bAzamPdvA"
};