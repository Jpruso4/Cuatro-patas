Function abrir(){
    document.getElementById("vent1").style.display="block"; 
}