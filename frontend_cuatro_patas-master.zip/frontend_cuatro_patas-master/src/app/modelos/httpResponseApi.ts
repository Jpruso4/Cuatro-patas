export class HttpResponseApi{
	estado?: boolean;
	mensaje?: string;
	data?: any;
}