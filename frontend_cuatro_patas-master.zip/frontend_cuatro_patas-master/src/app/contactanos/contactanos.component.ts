import { Component } from '@angular/core';

@Component({
    selector: 'contactanos',
    templateUrl: './contactanos.component.html',
    styleUrls: ['./contactanos.component.css']
})

export class ContactanosComponent {

    constructor(){}

}