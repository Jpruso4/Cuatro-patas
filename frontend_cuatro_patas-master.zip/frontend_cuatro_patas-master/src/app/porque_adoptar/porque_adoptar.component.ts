import { Component } from '@angular/core';

@Component({
    selector: 'porque-adoptar',
    templateUrl: './porque_adoptar.component.html',
    styleUrls: ['./porque_adoptar.component.css']
})

export class PorqueAdoptarComponent {

    constructor(){}

}